from django.shortcuts import render
from django.urls import path
from . import views
from django.contrib.auth.decorators import login_required




urlpatterns = [
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('register/', views.register, name='register'),
    path('', views.index, name='index'),
]


def register():
    return None


def logout_view():
    return None


def login_view():
    return None


def index():
    return None


