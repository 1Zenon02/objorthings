from django.urls import path
from django.contrib.auth import views as auth_views
from .views import custom_logout
from . import views
from django.contrib.auth.views import LogoutView


urlpatterns = [
    path('', views.index, name='index'),
    path('register/', views.register, name='register'),
    path('login/', views.login_view, name='login'),
    path('admin-register/', views.admin_register, name='admin_register'),
    path('admin-login/', views.admin_login, name='admin_login'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('calendar/', views.calendar_view, name='calendar'),
    path('calendar/add/', views.add_task, name='add_task'),
    path('calendar/edit/', views.edit_task, name='edit_task'),
    path('add-task/', views.add_task, name='add_task'),
    path('edit-task/<int:task_id>/', views.edit_task, name='edit_task'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('logout/', custom_logout, name='logout'),
    path('', views.index, name='index'),  # Ensure the index URL is nam
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),

    path('logout/', LogoutView.as_view(next_page='index'), name='logout'),






]
