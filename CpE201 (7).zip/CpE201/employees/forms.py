from django import forms
from django.contrib.auth import login
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.shortcuts import redirect, render
from .models import Task
from .models import Profile
from .models import Employee

from .models import RegisteredUser  # Replace Employee with actual model name





class RegistrationForm(UserCreationForm):
    address = forms.CharField(max_length=255, required=False)
    phone_number = forms.CharField(max_length=15, required=False)
    birth_date = forms.DateField(required=False, widget=forms.TextInput(attrs={'type': 'date'}))

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2', 'address', 'phone_number', 'birth_date']

    def save(self, commit=True):
        user = super(AdminRegistrationForm, self).save(commit=False)
        user.email = self.cleaned_data['email']
        user.first_name = self.cleaned_data['name']  # Save the name as the first name
        user.username = self.cleaned_data['admin_id']  # Use the admin ID for login
        user.is_staff = True  # Mark as admin
        if commit:
            user.save()
            # Now save the profile details
            profile = Profile.objects.get(user=user)
            profile.address = self.cleaned_data['address']
            profile.admin_id = self.cleaned_data['admin_id']
            profile.save()
        return user



    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exists():
            raise ValidationError('Email already exists')
        return email


class LoginForm(forms.Form):
    username = forms.CharField(max_length=150, widget=forms.TextInput(attrs={'placeholder': 'Username'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder': 'Password'}))


def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Get the role from the form
            role = form.cleaned_data.get('role')
            # Update the Profile with the selected role
            user.profile.role = role
            user.profile.save()

            # Log the user in and redirect to the home page
            login(request, user)
            return redirect('home')
    else:
        form = RegisterForm()
    return render(request, 'registration/register.html', {'form': form})


class RegisterForm:
    def __init__(self):
        self.cleaned_data = None

    pass

    def is_valid(self):
        pass

    def save(self):
        pass


class TaskForm(forms.ModelForm):
    class Meta:
        model = Task
        fields = ['title', 'description', 'date', 'time']
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date'}),
            'time': forms.TimeInput(attrs={'type': 'time'}),
        }


class AdminRegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    name = forms.CharField(max_length=100, required=True)
    address = forms.CharField(max_length=255, required=True)
    admin_id = forms.CharField(max_length=4, required=True, label="Admin ID (4 digits)")

    class Meta:
        model = User
        fields = ['name', 'email', 'address', 'admin_id', 'password1', 'password2']

    def save(self, commit=True):
        user = super(AdminRegistrationForm, self).save(commit=False)
        user.email = self.cleaned_data['email']
        user.is_staff = True  # Set admin rights
        user.first_name = self.cleaned_data['name']  # Save name as the first name
        user.username = self.cleaned_data['admin_id']  # Set admin ID as the username for login
        if commit:
            user.save()
        return user
class AdminLoginForm(AuthenticationForm):
    username = forms.CharField(max_length=4, label="Admin ID (4 digits)")
    password = forms.CharField(widget=forms.PasswordInput, label="Password")

class EmployeeRegistrationForm(forms.ModelForm):
    class Meta:
        model = Employee  # Referencing your Employee model
        fields = ['name', 'email', 'position']  # Include the fields you want in the form

    def save(self, commit=True):
        employee = super(EmployeeRegistrationForm, self).save(commit=False)

        # You can add additional logic here if needed (e.g., setting defaults)

        if commit:
            employee.save()  # Save the employee instance to the database
        return employee
