from django.contrib.auth import authenticate, login, logout
from django.shortcuts import render, redirect, get_object_or_404
from django import forms

from .forms import AdminRegistrationForm, AdminLoginForm
from .forms import RegistrationForm, LoginForm
from .forms import TaskForm
from .models import Task
from .models import Employee
from .forms import EmployeeRegistrationForm
from django.contrib.auth.decorators import login_required














def index(request):
    return render(request, 'index.html')

def register(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('index')
    else:
        form = RegistrationForm()
    return render(request, 'registration/register.html', {'form': form})

class EmployeeRegistrationForm(forms.ModelForm):
    class Meta:
        model = Employee  # Referencing your Employee model
        fields = ['name', 'email', 'position']  # Include the fields you want in the form

    def save(self, commit=True):
        user = super().save(commit=False)  # Correct usage of super()

        # You can add additional logic here if needed (e.g., setting defaults)

        if commit:
            username = self.cleaned_data['username'],
            email = self.cleaned_data['email'],
            password = self.cleaned_data['password'],  # Make sure to hash
            Employee.save()  # Save the employee instance to the database
        return Employee


def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('dashboard')
            else:
                return render(request, 'registration/login.html', {'form': form, 'error': 'Invalid credentials'})
    else:
        form = LoginForm()
    return render(request, 'registration/login.html', {'form': form})



def logout_view(request):
    logout(request)
    return redirect('index')


def dashboard(request, user=None):
    if request.user.is_authenticated:
        profile = request.user.profile
        return render(request, 'dashboard/base.html', {'user': request.user, 'profile': profile})


def calendar_view(request):
    tasks = Task.objects.all()  # Fetch all tasks from the database
    return render(request, 'calendar/calendar.html', {'tasks': tasks})

def add_task(request):
    tasks = Task.objects.all()

    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            form.save()  # Save the task to the database
            return redirect('calendar')  # Redirect to the calendar page
    else:
        form = TaskForm()
        context = {
            'tasks': tasks,  # Pass the tasks to the template
            'form': form
        }
    return render(request, 'calendar/add_task.html', {'form': form})


def edit_task(request, form=None, task_id=None):
    task = get_object_or_404(Task, id=task_id, user=request.user)
    if request.method == 'POST':
        if form.is_valid():
            task = form.save(commit=False)  # Don't save to the database yet
            task.user = request.user  # Assign the current logged-in user
            task.save()  # Now save the task with the user assigned
            return redirect('calendar')  # Redirect to the calendar page
    else:
        form = TaskForm(instance=task)
    return render(request, 'calendar/edit_task.html', {'form': form})

def custom_logout(request):
    logout(request)
    return redirect('index')

def index(request):
    return render(request, 'index.html')





# Admin Registration View
def admin_register(request):
    if request.method == 'POST':
        form = AdminRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')  # Redirect to index after registration
    else:
        form = AdminRegistrationForm()
    return render(request, 'admin_register.html', {'form': form})

def admin_login(request):
    if request.method == 'POST':
        form = AdminLoginForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('admin_dashboard')  # Redirect to the admin dashboard
    else:
        form = AdminLoginForm()
    return render(request, 'admin_login.html', {'form': form})


def admin_dashboard(request):
    employees = Employee.objects.all()  # Retrieve all employees
    return render(request, 'dashboard/admin_dashboard.html', {'employees': employees})



