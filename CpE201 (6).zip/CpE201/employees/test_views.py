from django.test import TestCase
from django.urls import reverse
from django.contrib.auth.models import User


class UserRegistrationTestCase(TestCase):

    def setUp(self):
        self.register_url = reverse('register')
        self.login_url = reverse('login')
        self.logout_url = reverse('logout')

    def test_registration(self):
        response = self.client.post(self.register_url, {
            'username': 'testuser',
            'email': 'testuser@example.com',
            'password': 'testpassword',
            'password_confirm': 'testpassword'
        })
        self.assertEqual(response.status_code, 302)
        self.assertTrue(User.objects.filter(username='testuser').exists())

    def test_login(self):

        User.objects.create_user(username='testuser', email='testuser@example.com', password='testpassword')

        response = self.client.post(self.login_url, {
            'username': 'testuser',
            'password': 'testpassword'
        })
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, '/')

    def test_logout(self):
        self.client.post(self.register_url, {
            'username': 'testuser',
            'email': 'testuser@example.com',
            'password': 'testpassword',
            'password_confirm': 'testpassword'
        })
        self.client.login(username='testuser', password='testpassword')

        response = self.client.get(self.logout_url)
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, '/')

        response = self.client.get(self.login_url)
        self.assertEqual(response.status_code, 200)
