from django.contrib.auth import authenticate, login, logout
from django.shortcuts import render, redirect, get_object_or_404
from .forms import RegistrationForm, LoginForm
from .forms import TaskForm
from .models import Task


def index(request):
    return render(request, 'index.html')

def register(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('index')
    else:
        form = RegistrationForm()
    return render(request, 'registration/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('dashboard')
            else:
                return render(request, 'registration/login.html', {'form': form, 'error': 'Invalid credentials'})
    else:
        form = LoginForm()
    return render(request, 'registration/login.html', {'form': form})



def logout_view(request):
    logout(request)
    return redirect('index')


def dashboard(request, user=None):
    if request.user.is_authenticated:
        profile = request.user.profile
        return render(request, 'dashboard/base.html', {'user': request.user, 'profile': profile})


def calendar_view(request):
    tasks = Task.objects.all()  # Fetch all tasks from the database
    return render(request, 'calendar/calendar.html', {'tasks': tasks})

def add_task(request):
    tasks = Task.objects.all()

    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            form.save()  # Save the task to the database
            return redirect('calendar')  # Redirect to the calendar page
    else:
        form = TaskForm()
        context = {
            'tasks': tasks,  # Pass the tasks to the template
            'form': form
        }
    return render(request, 'calendar/add_task.html', {'form': form})


def edit_task(request, form=None, task_id=None):
    task = get_object_or_404(Task, id=task_id, user=request.user)
    if request.method == 'POST':
        if form.is_valid():
            task = form.save(commit=False)  # Don't save to the database yet
            task.user = request.user  # Assign the current logged-in user
            task.save()  # Now save the task with the user assigned
            return redirect('calendar')  # Redirect to the calendar page
    else:
        form = TaskForm(instance=task)
    return render(request, 'calendar/edit_task.html', {'form': form})

def custom_logout(request):
    logout(request)
    return redirect('index')

def index(request):
    return render(request, 'index.html')







