from django.urls import path
from django.contrib.auth import views as auth_views
from .views import custom_logout
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('register/', views.register, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('calendar/', views.calendar_view, name='calendar'),
    path('calendar/add/', views.add_task, name='add_task'),
    path('calendar/edit/', views.edit_task, name='edit_task'),
    path('add-task/', views.add_task, name='add_task'),
    path('edit-task/<int:task_id>/', views.edit_task, name='edit_task'),

    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('logout/', custom_logout, name='logout'),
    path('', views.index, name='index'),  # Ensure the index URL is nam




    # Existing URLs



]
